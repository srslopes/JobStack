# JobStack
 Plataforma para conectar alunos e empresas a procura de estagiarios. Desenvolvido para a matéria de Estrutura de Dados, com o desafio de usar apenas a memória principal do computador.
